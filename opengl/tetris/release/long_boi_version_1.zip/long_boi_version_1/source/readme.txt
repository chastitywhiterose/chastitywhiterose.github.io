Long Boi Game / Chaste Tris

How to Play

WASD or Arrow keys to move the current block.
Z to rotate counter clockwise
X to rotate clockwise
C to hold block for later use(as in all modern Tetris games)


The original name of this game came from River Black Rose, who calls the Tetris I block "The Long Boi". The game started out only with this block but I have since added all the standard blocks as well as the standard rotations and colors for each block. It does not play exactly like a Tetris game because there is no gravity This makes it much more relaxing to play. Not much challenge but it is still a complete game. The next block only happens when you manually drop a block down onto the bottom of the field or it touches another block.

The code was written by me in C and uses OpenGl. I can make Linux or Windows versions for download upon request but it's still a work in progress as I add features to it.

When only the I block is enabled, the game is called Long Boi. When all 7 are included, it is called Chaste Tris. Both versions use all the same functions for collision detection and movement. 

